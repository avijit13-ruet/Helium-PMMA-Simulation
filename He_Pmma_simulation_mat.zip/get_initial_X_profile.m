function [X_He_steady, X_F_steady] = get_initial_X_profile()
% [X_He_steady, X_F_steady] = get_initial_X_profile()
%
% Solves the steady-state 1D Convection-Diffusion equation for gas species 
% using the Finite Difference Method (FDM) to generate smooth initial profiles.
% This profile assumes pre-pyrolysis conditions: only Helium injection 
% is active, and no fuel vapor is present.
%
% Governing Equation (Steady State):
% d^2X/dy^2 - (V/D) * dX/dy = 0
% FDM Discretization leads to a tridiagonal system A*X = B.

% --- Global Constants ---
global N_gas dy_gas D_He D_F V_He_inj

% Local variables for clarity
N_g = N_gas; 
dy = dy_gas; 
V = V_He_inj; % Initial velocity is solely due to Helium injection

% Boundary Values (Initial Conditions: No Pyrolysis)
X_He_surf = 1.0; % Surface (y=0): Pure Helium injection
X_F_surf = 0.0;  % Surface (y=0): No Fuel vapor
X_amb = 0.0;     % Ambient/Outer Boundary (y=L_gas): No Helium or Fuel

% --- 1. SOLVE FOR HELIUM MOLE FRACTION (X_He) ---

% Peclet Number P = V*dy/D_He (Dimensionless ratio of convection to diffusion)
P_He = V * dy / D_He;

% Initialize Matrix A (Tridiagonal) and Vector B (Boundary Conditions)
A = zeros(N_g);
B = zeros(N_g, 1);

for j = 1:N_g
    if j == 1
        % Surface Boundary Node (j=1): Dirichlet BC (Fixed at pure Helium)
        A(j, j) = 1; 
        B(j) = X_He_surf;
        
    elseif j == N_g
        % Ambient Boundary Node (j=N_g): Dirichlet BC (Fixed at ambient)
        A(j, j) = 1; 
        B(j) = X_amb;
        
    else
        % Interior Nodes (j=2 to N_g-1): Convection-Diffusion FDM
        % Discretization: X_{j-1} * (1 + P/2) + X_j * (-2) + X_{j+1} * (1 - P/2) = 0
        A(j, j-1) = 1 + P_He/2;
        A(j, j)   = -2;
        A(j, j+1) = 1 - P_He/2;
        B(j) = 0; % Internal nodes are homogeneous (no source term)
    end
end

% Solve the linear system A * X = B
X_He_steady = A \ B;


% --- 2. SOLVE FOR FUEL MOLE FRACTION (X_F) ---

% Peclet Number P_F = V*dy/D_F
P_F = V * dy / D_F;

A_F = zeros(N_g);
B_F = zeros(N_g, 1);

for j = 1:N_g
    if j == 1
        % Surface Boundary Node (j=1): Fixed at zero Fuel
        A_F(j, j) = 1; 
        B_F(j) = X_F_surf;
        
    elseif j == N_g
        % Ambient Boundary Node (j=N_g): Fixed at zero Fuel
        A_F(j, j) = 1; 
        B_F(j) = X_amb;
        
    else
        % Interior Nodes (j=2 to N_g-1)
        A_F(j, j-1) = 1 + P_F/2;
        A_F(j, j)   = -2;
        A_F(j, j+1) = 1 - P_F/2;
        B_F(j) = 0;
    end
end

% Solve the linear system A_F * X_F = B_F
X_F_steady = A_F \ B_F; 
end