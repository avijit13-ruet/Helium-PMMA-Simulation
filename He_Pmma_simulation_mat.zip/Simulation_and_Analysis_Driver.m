% Simulation_and_Analysis_Driver.m
% Executes a single baseline simulation with profile plots, 
% followed by the full parametric analysis with comparison plots.

clc; clear all; close all;

%% --- 0. DEFINE ALL GLOBAL PHYSICAL CONSTANTS (MUST be set before any function call) ---
% Solid Phase Globals
global N dx rho_s cp_s k_s E R A Lg q_ext T_amb
% Gas Phase Globals
global N_gas dy_gas rho_gas D_He D_F V_He_inj h_c
% Molecular Weight Globals
global MW_He MW_Air MW_F

% --- PHYSICAL CONSTANTS --
rho_s = 1190; cp_s = 1466; k_s = 0.18; Lg = 1.8e6; T_amb = 298.15;
R = 8.314; E = 150000; A = 2.57e17; % Pyrolysis Kinetics
rho_gas = 1.2; D_He = 2.0e-4; D_F = 5.0e-6; h_c = 15; % Gas/Convection Properties

MW_He = 0.0040; MW_Air = 0.02896; MW_F = 0.1001; % Molecular Weights

% --- Grid Setup (MUST be set globally) ---
L = 0.01; N = 40; dx = L/(N-1);
L_gas = 0.01; N_gas = 40; dy_gas = L_gas/(N_gas-1);

x_solid = linspace(0, L, N);
y_gas = linspace(0, L_gas, N_gas);

% --- Baseline Parameters for Phase 1 ---
q_baseline = 25000; % W/m2
V_He_baseline = 0.005; % m/s

%% --- PHASE 1: BASELINE SIMULATION & PROFILE PLOTS ---
disp('--- PHASE 1: Running Baseline Simulation for Profile Analysis ---');

% Set globals for the baseline run
q_ext = q_baseline;
V_He_inj = V_He_baseline;

options = odeset('RelTol',1e-5,'AbsTol',1e-7,'MaxStep',0.001,'InitialStep',1e-7);

% FIX APPLIED: Removed redundant parameters from ode15s call
[t_full, Y_full] = ode15s(@Coupled_MOL, [0 150], get_initial_conditions(N), options);

% Extract the final time step profile
T_final = Y_full(end, 1:N);
X_He_final = Y_full(end, N+1 : N+N_gas);
X_F_final = Y_full(end, N+N_gas+1 : end);

% --- Plotting Profiles at Final Time (t=150s) ---
figure(1);
subplot(1, 2, 1);
plot(x_solid*1000, T_final, 'r-', 'LineWidth', 2);
xlabel('Depth into Solid, $x$ (mm)', 'interpreter', 'latex');
ylabel('Temperature $T$ (K)', 'interpreter', 'latex');
title('A. Solid Temperature Profile (t=150s)', 'interpreter', 'latex');
grid on;

subplot(1, 2, 2);
hold on;
plot(y_gas*1000, X_He_final, 'b-', 'LineWidth', 2, 'DisplayName', '$X_{He}$');
plot(y_gas*1000, X_F_final, 'g-', 'LineWidth', 2, 'DisplayName', '$X_{F}$ (Fuel)');
xlabel('Height into Gas Phase, $y$ (mm)', 'interpreter', 'latex');
ylabel('Mole Fraction $X_i$', 'interpreter', 'latex');
title('B. Gas Species Profiles (t=150s)', 'interpreter', 'latex');
legend('show', 'Location', 'NorthEast', 'interpreter', 'latex');
grid on;
set(gcf, 'Name', 'Phase 1: Baseline Profiles');

disp('Phase 1 Complete. Figure 1 generated.');
pause(1); % Pause to allow user to view the first figure

%% --- PHASE 2: PARAMETRIC ANALYSIS & COMPARISON PLOTS ---
disp('--- PHASE 2: Running Parametric Sweep for Comparison Analysis ---');

% --- Define the studies to run (using the full function call) ---
q_ext_list = [10000, 15000, 20000, 25000, 30000]; % W/m2
V_He_fixed = 0.005; % m/s 
results_q = cell(length(q_ext_list), 1);

V_inj_list = [0.005, 0.01, 0.02, 0.03, 0.05]; % m/s
q_ext_fixed = 25000; % W/m2 
results_V = cell(length(V_inj_list), 1);

colors = lines(5);

% EXECUTE STUDY A: VARY Q_EXT 
for i = 1:length(q_ext_list)
    q_in = q_ext_list(i);
    fprintf('Running q_ext = %d W/m2...\n', q_in);
    % Main_Coupled_Simulation handles setting the global variables internally
    [t, T_surf, X_He_surf, X_F_surf] = Main_Coupled_Simulation(q_in, V_He_fixed);
    results_q{i} = struct('q_ext', q_in, 't', t, 'T_surf', T_surf, 'X_He_surf', X_He_surf, 'X_F_surf', X_F_surf);
end

% EXECUTE STUDY B: VARY V_HE_INJ 
for i = 1:length(V_inj_list)
    V_in = V_inj_list(i);
    fprintf('Running V_He_inj = %.3f m/s...\n', V_in);
    [t, T_surf, X_He_surf, X_F_surf] = Main_Coupled_Simulation(q_ext_fixed, V_in);
    results_V{i} = struct('V_inj', V_in, 't', t, 'T_surf', T_surf, 'X_He_surf', X_He_surf, 'X_F_surf', X_F_surf);
end


% ... (Code before figure 2 remains the same)

% --- Plotting Comparison Results (Figure 2) ---
figure(2);
% 2A: Surface Temperature (Thermal Response)
subplot(1, 2, 1);
hold on;
for i = 1:length(q_ext_list)
    plot(results_q{i}.t, results_q{i}.T_surf, 'Color', colors(i,:), 'LineWidth', 2, 'DisplayName', [num2str(results_q{i}.q_ext/1000), ' kW/m^2']);
end
xlabel('Time (s)');
ylabel('Surface Temperature $T_s$ (K)','interpreter','latex');

% *** CORRECTION FOR TITLE A: Simplified LaTeX for dynamic string ***
title(sprintf('A. Surface Temperature ($V_{He,inj}=%.3f$ m/s fixed)', V_He_fixed),'interpreter','latex');

legend('show', 'Location', 'SouthEast');
grid on;

% 2B: Surface Fuel Mole Fraction (Mass Response)
subplot(1, 2, 2);
hold on;
for i = 1:length(q_ext_list)
    plot(results_q{i}.t, results_q{i}.X_F_surf, 'Color', colors(i,:), 'LineWidth', 2, 'DisplayName', [num2str(results_q{i}.q_ext/1000), ' kW/m^2']);
end
xlabel('Time (s)');
ylabel('Surface Fuel Mole Fraction $X_{F,surf}$','interpreter','latex');
title('B. Fuel Mass Blowing (Varying $q_{ext}$)', 'interpreter','latex');
legend('show', 'Location', 'NorthWest');
grid on;
set(gcf, 'Name', 'Phase 2: Parametric Sweep - Varying q_ext');

% --- Plotting Comparison Results (Figure 3) ---
figure(3);
% 3A: Surface Temperature (Thermal Response)
subplot(1, 2, 1);
hold on;
for i = 1:length(V_inj_list)
    plot(results_V{i}.t, results_V{i}.T_surf, 'Color', colors(i,:), 'LineWidth', 2, 'DisplayName', [num2str(results_V{i}.V_inj*1000), ' mm/s']);
end
xlabel('Time (s)');
ylabel('Surface Temperature $T_s$ (K)','interpreter','latex');

% *** CORRECTION FOR TITLE B: Simplified LaTeX for dynamic string ***
title(sprintf('A. Surface Temperature ($q_{ext}=%.0f$ kW/m^2 fixed)', q_ext_fixed/1000),'interpreter','latex');

legend('show', 'Location', 'SouthEast');
grid on;

% 3B: Surface Fuel Mole Fraction (Dilution/Mass Response)
subplot(1, 2, 2);
hold on;
for i = 1:length(V_inj_list)
    plot(results_V{i}.t, results_V{i}.X_F_surf, 'Color', colors(i,:), 'LineWidth', 2, 'DisplayName', [num2str(results_V{i}.V_inj*1000), ' mm/s']);
end
xlabel('Time (s)');
ylabel('Surface Fuel Mole Fraction $X_{F,surf}$','interpreter','latex');
title('B. Fuel Mass Blowing (Varying $V_{He,inj}$)', 'interpreter','latex');
legend('show', 'Location', 'NorthWest');
grid on;
set(gcf, 'Name', 'Phase 2: Parametric Sweep - Varying V_He_inj');

disp('Phase 2 Complete. Figures 2 and 3 generated.');