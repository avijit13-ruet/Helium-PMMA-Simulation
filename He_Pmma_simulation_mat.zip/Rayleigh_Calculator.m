function [sigma_mix_history, T_meas_simulated] = Rayleigh_Calculator(t_out, Y_out)
% [sigma_mix_history, T_meas_simulated] = Rayleigh_Calculator(t_out, Y_out)
% Calculates the effective Rayleigh Cross-Section (sigma_mix) and simulates
% the temperature extraction process (T_meas) using the coupled model output.
%
% This is the core diagnostic step for Phase 3, connecting simulation
% results (X_He, X_F) to experimental observables.

% --- Global Constants ---
global N N_gas sigma_Air sigma_He sigma_F P_atm R_univ T_amb

% --- 1. SETUP & CONSTANT CALCULATION ---
N_solid = N;
N_gas_species = N_gas;
N_time = length(t_out);

% Initialize output vectors
sigma_mix_history = zeros(N_time, 1);
T_meas_simulated = zeros(N_time, 1);

% --- Simulated Experimental Reference/Input ---
% K: Calibration constant (determined experimentally with pure Helium flow)
T_ref = T_amb;          % Known reference temperature (K)
% Define a constant reference signal for pure Helium flow (Arbitrary Units)
% In an experiment, this would be measured during the calibration phase.
I_R_He_ref = 100;       
sigma_He_ref = sigma_He; % Cross-section of pure Helium

% K calculation (Eq. 123 in doc): K = (I_R,He * R * T_ref) / (P * sigma_He_ref)
% This constant relates the measured signal intensity (I_R) to the gas state (T, P, sigma).
K = (I_R_He_ref * R_univ * T_ref) / (P_atm * sigma_He_ref);

% Assume a constant, arbitrary Rayleigh signal measured at the surface 
% (For demonstration, we assume the signal drops to 80% of the He reference due to the
% introduction of Air/Fuel at the point of measurement).
I_R_meas_simulated = I_R_He_ref * 0.8; 

% --- 2. TIME LOOP: CALCULATE EFFECTIVE CROSS-SECTION (sigma_mix) ---
for i = 1:N_time
    % Extract current mole fractions at the surface (gas node 1)
    % Y_out columns: [T1..TN] [X_He,1..N_gas] [X_F,1..N_gas]
    X_He_surf = Y_out(i, N_solid + 1);
    X_F_surf = Y_out(i, N_solid + N_gas_species + 1);
    
    % Assume remaining mole fraction is Air (N2/O2)
    X_Air_surf = 1 - X_He_surf - X_F_surf;
    
    % Ensure mole fractions are physical (0 <= X <= 1)
    X_Air_surf = max(0, X_Air_surf); 
    
    % Calculate Effective Cross-Section: sigma_mix = SUM(Xi * sigma_i)
    % This is the key coupling between the simulation (mole fractions) and 
    % the experimental diagnostic.
    sigma_mix = X_He_surf * sigma_He + ...
                X_F_surf * sigma_F + ...
                X_Air_surf * sigma_Air;
    
    sigma_mix_history(i) = sigma_mix;
    
    % --- 3. SIMULATE TEMPERATURE EXTRACTION (T_meas) ---
    % T_meas = (K * P * sigma_mix(Xi)) / (R * I_R_meas)
    % This is the inversion step: using the measured signal (I_R) and the 
    % calculated sigma_mix to 'measure' the temperature (T).
    T_meas = (K * P_atm * sigma_mix) / (R_univ * I_R_meas_simulated);
    
    T_meas_simulated(i) = T_meas;
end

% --- 4. PLOTTING (Diagnostic Visualization) ---
figure;

% Subplot 1: Effective Rayleigh Cross-Section
subplot(2, 1, 1);
plot(t_out, sigma_mix_history, 'b-', 'LineWidth', 2);
title('Effective Rayleigh Cross-Section (\sigma_{mix}) at Surface');
xlabel('Time (s)');
ylabel('\sigma_{mix} / \sigma_{Air}');
grid on;

% Subplot 2: Simulated Measured Temperature (T_{meas}) vs. Model Temperature (T_s)
subplot(2, 1, 2);
hold on;
% Model Surface Temperature (T_s) is the first column of Y_out
T_s_model = Y_out(:, N_solid); 
plot(t_out, T_s_model, 'r-', 'LineWidth', 2, 'DisplayName', 'Model T_s (Y_{out}(:,1))');
plot(t_out, T_meas_simulated, 'k--', 'LineWidth', 2, 'DisplayName', 'Simulated T_{meas}');
title('Temperature Comparison: Model Surface vs. Simulated Measured');
xlabel('Time (s)');
ylabel('Temperature (K)');
legend('show', 'Location', 'southeast');
grid on;
hold off;

end