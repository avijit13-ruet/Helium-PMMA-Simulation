function Y_initial = get_initial_conditions(N)
% get_initial_conditions.m: Returns the full initial state vector for ODE solver.
% N is the number of solid nodes.

% --- Get Global Constants (MUST be defined in Main_Coupled_Simulation.m or the driver) ---
global T_amb N_gas V_He_inj D_He D_F

% --- Grid Setup (MUST match Simulation_and_Analysis_Driver settings) ---
L = 0.01; N_solid = N; dx = L/(N_solid-1);
L_gas = 0.01; N_gas = 40; dy_gas = L_gas/(N_gas-1);
% If the constants aren't defined in the base workspace, set defaults for safety
if isempty(T_amb), T_amb = 298.15; end
if isempty(V_He_inj), V_He_inj = 0.005; end
if isempty(D_He), D_He = 2.0e-4; end % Default placeholder value
if isempty(D_F), D_F = 5.0e-6; end  % Default placeholder value

% --- 3. INITIAL CONDITIONS ---
% T_initial: Solid is at ambient temperature
T_initial = T_amb*ones(N_solid,1); 

% X_initial: Gas profiles start at a non-pyrolysis steady state (He injection only)
% This requires the function get_initial_X_profile.m to be available
[X_He_steady, X_F_steady] = get_initial_X_profile(); 

% Combined state vector
Y_initial = [T_initial; X_He_steady; X_F_steady];

end