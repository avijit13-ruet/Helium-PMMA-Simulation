function dXdt = Gas_Species_MOL(T_s, m_double_prime, X_He, X_F)
% Calculates the time derivatives (dX/dt) for the gas phase species.
global N_gas dy_gas rho_gas D_He D_F R_univ V_He_inj

dXdt = zeros(2 * N_gas, 1);
N = N_gas;
dy = dy_gas;

% --- 1. Surface Velocity (Blowing Effect) ---
% For the full simulation, the mass loss m'' creates a blowing velocity vw.
% For the pure Q1 Helium Stability test, vw is replaced by V_He_inj.
% Here, we use a single velocity term 'V_conv'
if m_double_prime > 1e-6 % If pyrolysis has started
    V_conv = m_double_prime / rho_gas; % Fuel blowing velocity (y=0) [cite: 98]
else
    V_conv = V_He_inj; % Helium injection velocity (Calibration/Pre-pyrolysis)
end

% --- 2. Calculate Surface Mole Fractions (Boundary Condition at y=0) ---
% When m'' > 0, the surface flux is a mix of Fuel and Helium.
% X_F_surface and X_He_surface define the concentration at the interface.
if V_conv == V_He_inj % Calibration Phase (Q1)
    X_He_surface = 1.0; % Pure Helium injection [cite: 15]
    X_F_surface = 0.0;  % No fuel blowing
else % Pyrolysis Phase
    % The fuel flux from the solid surface is balanced against the Helium/Air flux
    % The most simplified approach assumes the surface gas is pure Fuel (MMA) vapor,
    % but a more accurate model uses mass fraction balance (beyond this step).
    % Simplified: If blowing, assume pure fuel at surface, no He/Air
    X_F_surface = 1.0;
    X_He_surface = 0.0;
end

% --- 3. Interior Nodes (FDM Discretization) ---
for j = 2:N-1
    % Convection Term (Central Difference)
    Conv_He = rho_gas * V_conv * (X_He(j+1) - X_He(j-1)) / (2 * dy);
    Conv_F  = rho_gas * V_conv * (X_F(j+1) - X_F(j-1)) / (2 * dy);

    % Diffusion Term (Central Difference for second derivative)
    Diff_He = (rho_gas * D_He) * (X_He(j+1) - 2*X_He(j) + X_He(j-1)) / (dy^2);
    Diff_F  = (rho_gas * D_F) * (X_F(j+1) - 2*X_F(j) + X_F(j-1)) / (dy^2);

    % ODE System: dX/dt = (Diffusion - Convection) / rho
    dXdt(j)     = (Diff_He - Conv_He) / rho_gas;
    dXdt(j + N) = (Diff_F - Conv_F) / rho_gas;
end

% --- 4. Boundary Conditions ---

% Node 1 (y=0: PMMA/Injector Surface)
% Enforce Dirichlet BC by setting the derivatives to zero and defining the value
% Note: In the combined solver, these values will be fixed based on the surface X_i.
dXdt(1) = 0;
dXdt(N + 1) = 0; 
X_He(1) = X_He_surface;
X_F(1) = X_F_surface;

% Node N (y=L_gas: Free Stream/Ambient Air)
% Ambient condition: X_He = 0, X_F = 0
dXdt(N) = 0;
dXdt(2*N) = 0;
X_He(N) = 0.0;
X_F(N) = 0.0;

% Return the derivative vector (only for interior nodes if using explicit solver)
% Since the combined solver handles the entire vector, we just set dXdt(1) and dXdt(N) to 0.
dXdt = [dXdt(1:N); dXdt(N+1:2*N)];

end