function [t_out, T_out, X_He_surf_out, X_F_surf_out] = Main_Coupled_Simulation(q_in, V_in)
% Main_Coupled_Simulation.m: Driver function for the 1D Coupled Pyrolysis and Gas Transport Model
% Accepts q_ext (external heat flux) and V_He_inj (Helium injection velocity) as inputs.

% --- 0. INITIALIZATION (Define all global variables) ---
global N dx rho_s cp_s k_s E R A Lg q_ext T_amb
global N_gas dy_gas rho_gas D_He D_F V_He_inj h_c cp_air cp_He
global MW_He MW_Air MW_F
global sigma_Air sigma_He sigma_F P_atm R_univ

% --- 1. PHYSICAL CONSTANTS (Use input arguments for variable parameters) ---
P_atm = 101325; R_univ = 8.314; R = 8.314; % Pressure, Universal Gas Constant

% Diagnostic Constants (Rayleigh Cross-Sections)
sigma_Air = 1.0;
sigma_He = 0.015;  
sigma_F = 4.500;   

% Solid Properties
rho_s = 1190; cp_s = 1466; k_s = 0.18; Lg = 1.8e6; T_amb = 298.15;

% Pyrolysis Kinetics
E = 150000; A = 2.57e17;

% External Input & Gas Phase Parameters
q_ext = q_in;        % Set using input argument
V_He_inj = V_in;     % Set using input argument
rho_gas = 1.2;
D_He = 2.0e-4;
D_F = 5.0e-5;
h_c = 15;

% Molecular Weights
MW_He = 0.0040; MW_Air = 0.02896; MW_F = 0.1001;

% --- 2. GRID SETUP ---
L = 0.01; N = 40; dx = L/(N-1);
L_gas = 0.01; N_gas = 40; dy_gas = L_gas/(N_gas-1);
N_solid = N;

% --- 3. INITIAL CONDITIONS & STIFFNESS FIX ---
T_initial = T_amb*ones(N,1); 

% Call the dependency (must be in the same folder)
[X_He_steady, X_F_steady] = get_initial_X_profile(); 

Y_initial = [T_initial; X_He_steady; X_F_steady];
tspan = [0 150];

% --- 4. SOLVER EXECUTION ---
% Use ode15s for stiff ODE system
options = odeset('RelTol',1e-5,'AbsTol',1e-7,'MaxStep',0.001,'InitialStep',1e-7);

disp(['Starting Simulation: q_ext=', num2str(q_in), ' W/m2, V_He_inj=', num2str(V_in), ' m/s']);
[t_out, Y_out] = ode15s(@Coupled_MOL, tspan, Y_initial, options);
disp('Simulation Complete.');

% --- 5. EXTRACT KEY SURFACE RESULTS FOR ANALYSIS ---
% T_out is the first temperature node (surface)
T_out = Y_out(:, 1); 
% X_He_surf_out is the first Helium mole fraction node (surface)
X_He_surf_out = Y_out(:, N_solid + 1); 
% X_F_surf_out is the first Fuel mole fraction node (surface)
X_F_surf_out = Y_out(:, N_solid + N_gas + 1); 

end