% Parameter_Study_q_ext.m
% This script runs the coupled pyrolysis model for various external heat
% fluxes (q_ext) and plots the surface temperature history (Ts) for comparison.
%
% NOTE: Ensure Main_Coupled_Simulation.m, Coupled_MOL.m, 
% get_initial_X_profile.m, and Rayleigh_Calculator.m are in the same folder.

clc; clear; close all;

% --- 1. DEFINE PARAMETER RANGE ---
% Define the list of external heat fluxes (W/m2) to test.
q_ext_list = [10000, 15000, 20000, 25000, 30000, 35000, 40000]; % 10 kW/m2 to 40 kW/m2
num_runs = length(q_ext_list);

% Structure to store results for plotting
all_Ts_results = struct('q_ext', [], 't', [], 'Ts', []);

% --- 2. EXECUTE SIMULATIONS IN A LOOP ---
fprintf('Starting Parameter Study for q_ext...\n');
figure(1);
hold on; 
title('Comparative PMMA Surface Temperature Rise vs. Time');
xlabel('Time (s)');
ylabel('Surface Temperature (K)');
grid on;
set(gca, 'FontSize', 14);

for i = 1:num_runs
    this_q_ext = q_ext_list(i);
    
    % --- Step A: Assign new q_ext to the base workspace ---
    % This is necessary because Main_Coupled_Simulation.m reads global
    % variables defined at the start of its execution. We temporarily
    % change the value it will read.
    assignin('base', 'q_ext_override', this_q_ext); 
    
    % --- Step B: Run the main simulation script ---
    % We execute the script, which will use the overridden q_ext value.
    try
        fprintf('Running Case %d/%d: q_ext = %.0f W/m2 (%.1f kW/m2)\n', ...
                i, num_runs, this_q_ext, this_q_ext/1000);
                
        % Execute Main_Coupled_Simulation.m without displaying its individual plots
        evalin('base', 'Main_Coupled_Simulation');
        
        % --- Step C: Retrieve results from the base workspace ---
        t_out = evalin('base', 't_out');
        Y_out = evalin('base', 'Y_out');
        
        % Surface Temperature is the first column
        Ts_history = Y_out(:, 1);
        
        % Store results
        all_Ts_results(i).q_ext = this_q_ext;
        all_Ts_results(i).t = t_out;
        all_Ts_results(i).Ts = Ts_history;
        
        % --- Step D: Plot on the comparative figure ---
        plot(t_out, Ts_history, 'LineWidth', 2, ...
             'DisplayName', sprintf('q_{ext} = %.1f kW/m^2', this_q_ext/1000));
             
    catch ME
        warning('Simulation failed for q_ext = %.0f W/m2: %s', this_q_ext, ME.message);
        % Continue to the next run if one fails
        continue; 
    end
end

% Finalize plot settings
legend('Location', 'bestoutside');
hold off;

fprintf('Parameter study complete. Results plotted in Figure 1.\n');

% --- 3. CLEAN UP BASE WORKSPACE (Optional but good practice) ---
% Remove the temporary global variable
evalin('base', 'clear q_ext_override');