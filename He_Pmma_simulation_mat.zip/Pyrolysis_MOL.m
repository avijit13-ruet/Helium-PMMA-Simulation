function dTdt = Pyrolysis_MOL(t, T)
% Derivative function for 1D Transient Heat Conduction in PMMA pyrolysis
global N dx rho_s cp_s k_s E R A Lg q_ext T_amb

dTdt = zeros(N, 1);
Ts = T(1); % Surface Temperature (T_1)

% --- I. INTERIOR NODES (i=2 to N-1) ---
for i = 2:(N-1)
    % Conduction Term: d^2T/dx^2 (Central FD)
    d2Tdx2 = (T(i+1) - 2*T(i) + T(i-1)) / (dx^2);
    
    % Energy Eq: dT/dt = (k / rho*cp) * d^2T/dx^2
    dTdt(i) = (k_s / (rho_s * cp_s)) * d2Tdx2;
end

% --- II. REAR BOUNDARY (T_N): Adiabatic (dT/dx = 0) ---
% Approximation using fictitious node
dTdt(N) = (k_s / (rho_s * cp_s)) * (2 * (T(N-1) - T(N)) / (dx^2));

% --- III. FRONT SURFACE (T_1): Energy Balance ---

% 1. Mass Flux (m_double_prime)
m_double_prime = 0;
if Ts >= 573
    m_double_prime = rho_s * A * exp(-E / (R * Ts));
end

% 2. Surface Heat Fluxes
epsilon = 0.9;
sigma = 5.67e-8;

q_loss_rad = epsilon * sigma * (Ts^4 - T_amb^4);

% Net energy remaining to conduct into the solid
q_net = q_ext - q_loss_rad - (m_double_prime * Lg);

% 3. Apply FD to the surface node T_1 (Control Volume, dx/2 thick)
%q_conduction_in = k_s * (T(1) - T(2)) / dx;
q_conduction_in = k_s * (T(2) - T(1)) / dx; % Correct direction, heat flows inward

% Solve for dTdt(1)
dTdt(1) = (q_net - q_conduction_in) / (rho_s * cp_s * (dx / 2));
dTdt = max(min(dTdt, 100), -10); % Prevent extreme values (temporary debug)

end
