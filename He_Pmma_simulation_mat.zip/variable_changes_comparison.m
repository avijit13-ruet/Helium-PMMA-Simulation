% variable_changes_comparison.m
clc; clear;

% --- Prepare parameter sets ---
q_ext_list = [10000, 15000, 20000, 25000, 30000, 35000, 40000];
rho_s_variations = [1100 1190 1280]; % Example density values per q_ext group
T_amb_fixed = 298;                  % Fixed temperature for all runs

all_results = {}; % Store all outputs for plotting

% --- Main simulation loop ---
for iq = 1:length(q_ext_list)
    this_q_ext = q_ext_list(iq);
    
    for irho = 1:length(rho_s_variations)
        this_rho = rho_s_variations(irho);

        % Assign params in base workspace so your existing code reads them
        assignin('base', 'q_ext', this_q_ext);
        assignin('base', 'rho_s', this_rho);
        assignin('base', 'T_amb', T_amb_fixed);

        fprintf('Run: q_ext=%d, rho_s=%d\n', this_q_ext, this_rho);

        % Call your unchanged simulation script/function here
        Main_Coupled_Simulation;

        t_out = evalin('base', 't_out');
        Y_out = evalin('base', 'Y_out');

        all_results{iq,irho} = struct('q_ext', this_q_ext, ...
                                      'rho_s', this_rho, ...
                                      't', t_out, ...
                                      'Y', Y_out);
    end
end

% --- Plot single figure with multiple subplots ---
figure;

for iq = 1:length(q_ext_list)
    subplot(3, 3, iq); % 3x3 grid for 7 q_ext values, expand if needed
    hold on;
    colors = {'k', 'r', 'b'}; % colors per rho_s
    legendEntries = cell(length(rho_s_variations),1);

    for irho = 1:length(rho_s_variations)
        result = all_results{iq, irho};
        % assume surface temperature is the first column
        plot(result.t, result.Y(:,1), 'Color', colors{irho}, 'LineWidth', 1.5);
        legendEntries{irho} = sprintf('rho_s=%d', result.rho_s);
    end

    title(sprintf('q_{ext} = %d W/m^2', q_ext_list(iq)));
    xlabel('Time (s)');
    ylabel('Surface Temperature (K)');
    legend(legendEntries, 'Location', 'best');
    grid on;
    hold off;
end

sgtitle('Surface Temperature Comparison for Various q_{ext} and \rho_s');
