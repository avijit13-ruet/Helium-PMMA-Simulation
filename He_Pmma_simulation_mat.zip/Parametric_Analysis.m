% Parametric_Analysis.m: Executes deep dive studies on q_ext and V_He_inj

clc; clear all;

% --- Define the studies to run ---

% Study A: Vary External Heat Flux (q_ext)
q_ext_list = [10000, 15000, 20000, 25000, 30000]; % W/m2
V_He_fixed = 0.005; % m/s (Fixed injection velocity)
results_q = cell(length(q_ext_list), 1);

% Study B: Vary Helium Injection Velocity (V_He_inj)
V_inj_list = [0.005, 0.01, 0.02, 0.03, 0.05]; % m/s
q_ext_fixed = 25000; % W/m2 (Fixed heat flux)
results_V = cell(length(V_inj_list), 1);

% Colors for plots
colors = lines(5);

%% --- EXECUTE STUDY A: VARY Q_EXT ---
disp('--- Running Study A: Varying External Heat Flux (q_ext) ---');
for i = 1:length(q_ext_list)
    q_in = q_ext_list(i);
    fprintf('Running q_ext = %d W/m2...\n', q_in);
    
    % Call the updated function
    [t, T_surf, X_He_surf, X_F_surf] = Main_Coupled_Simulation(q_in, V_He_fixed);
    
    results_q{i} = struct('q_ext', q_in, 't', t, 'T_surf', T_surf, ...
                          'X_He_surf', X_He_surf, 'X_F_surf', X_F_surf);
end

%% --- EXECUTE STUDY B: VARY V_HE_INJ ---
disp('--- Running Study B: Varying Helium Injection Velocity (V_He_inj) ---');
for i = 1:length(V_inj_list)
    V_in = V_inj_list(i);
    fprintf('Running V_He_inj = %.3f m/s...\n', V_in);

    % Call the updated function
    [t, T_surf, X_He_surf, X_F_surf] = Main_Coupled_Simulation(q_ext_fixed, V_in);
    
    results_V{i} = struct('V_inj', V_in, 't', t, 'T_surf', T_surf, ...
                          'X_He_surf', X_He_surf, 'X_F_surf', X_F_surf);
end

%% --- PLOTTING ANALYSIS RESULTS ---

% Figure 1: Impact of q_ext on Thermal and Mass Response
figure(1);
% Replaced sgtitle with a title on the first subplot for compatibility.

% 1A: Surface Temperature (Thermal Response)
subplot(1, 2, 1);
hold on;
for i = 1:length(q_ext_list)
    plot(results_q{i}.t, results_q{i}.T_surf, 'Color', colors(i,:), 'LineWidth', 2, 'DisplayName', [num2str(results_q{i}.q_ext/1000), ' kW/m^2']);
end
xlabel('Time (s)');
ylabel('Surface Temperature $T_s$ (K)','interpreter','latex');
% Use the title to include the fixed parameter for context
title(['A. Surface Temperature ($V_{He,inj}=', num2str(V_He_fixed), ' \text{m/s}$ fixed)'],'interpreter','latex');
legend('show', 'Location', 'SouthEast');
grid on;

% 1B: Surface Fuel Mole Fraction (Mass Response)
subplot(1, 2, 2);
hold on;
for i = 1:length(q_ext_list)
    plot(results_q{i}.t, results_q{i}.X_F_surf, 'Color', colors(i,:), 'LineWidth', 2, 'DisplayName', [num2str(results_q{i}.q_ext/1000), ' kW/m^2']);
end
xlabel('Time (s)');
ylabel('Surface Fuel Mole Fraction $X_{F,surf}$','interpreter','latex');
title('B. Fuel Mass Blowing','interpreter','latex');
legend('show', 'Location', 'NorthWest');
grid on;

% Figure 2: Impact of V_He_inj on Thermal and Mass Response
figure(2);
% Replaced sgtitle with a title on the first subplot for compatibility.

% 2A: Surface Temperature (Thermal Response)
subplot(1, 2, 1);
hold on;
for i = 1:length(V_inj_list)
    plot(results_V{i}.t, results_V{i}.T_surf, 'Color', colors(i,:), 'LineWidth', 2, 'DisplayName', [num2str(results_V{i}.V_inj*1000), ' mm/s']);
end
xlabel('Time (s)');
ylabel('Surface Temperature $T_s$ (K)','interpreter','latex');
% Use the title to include the fixed parameter for context
title(['A. Surface Temperature ($q_{ext}=', num2str(q_ext_fixed/1000), ' \text{kW/m}^2$ fixed)'],'interpreter','latex');
legend('show', 'Location', 'SouthEast');
grid on;

% 2B: Surface Fuel Mole Fraction (Dilution/Mass Response)
subplot(1, 2, 2);
hold on;
for i = 1:length(V_inj_list)
    plot(results_V{i}.t, results_V{i}.X_F_surf, 'Color', colors(i,:), 'LineWidth', 2, 'DisplayName', [num2str(results_V{i}.V_inj*1000), ' mm/s']);
end
xlabel('Time (s)');
ylabel('Surface Fuel Mole Fraction $X_{F,surf}$','interpreter','latex');
title('B. Fuel Mass Blowing','interpreter','latex');
legend('show', 'Location', 'NorthWest');
grid on;