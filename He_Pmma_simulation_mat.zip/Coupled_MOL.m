function dYdt = Coupled_MOL(t, Y)
% Coupled_MOL: Derivative function for the 1D Coupled Pyrolysis and Gas Transport Model
% Solves dT/dt and dX/dt for all solid and gas nodes using Method of Lines (MOL).

global N dx rho_s cp_s k_s E R A Lg q_ext T_amb
global N_gas dy_gas rho_gas D_He D_F V_He_inj h_c
global MW_He MW_Air MW_F

% --- 1. STATE VECTOR SPLIT & INITIALIZATION ---
N_solid = N;
N_gas_species = N_gas;

% Y = [T_solid (1:N); X_He (N+1:N+N_gas); X_F (N+N_gas+1:end)]
T = Y(1:N_solid);
X_He = Y(N_solid+1:N_solid+N_gas_species);
X_F = Y(N_solid+N_gas_species+1:end);

% Initialize derivatives vector
dTdt = zeros(N_solid, 1);
dYdt_gas = zeros(2 * N_gas_species, 1);

% --- 2. SOLID PHASE (Temperature T) ---

% Interior spatial derivatives for temperature (i=2 to N-1) - Standard Heat Conduction
for i = 2:N_solid-1
    d2Tdx2 = (T(i+1) - 2*T(i) + T(i-1)) / (dx^2);
    dTdt(i) = (k_s / (rho_s * cp_s)) * d2Tdx2;
end

% Rear boundary (i=N): Adiabatic (dT/dx = 0)
% Using 2nd order fictitious node approximation
dTdt(N_solid) = (k_s / (rho_s * cp_s)) * (2 * (T(N_solid-1) - T(N_solid)) / (dx^2));

% --- Front Surface (i=1): Energy Balance (with Smoothed Kinetics) ---
Ts = T(1);
T_gas_surf = Ts; % Gas temperature equals solid surface temperature

% 2.1 Pyrolysis Mass Flux (m_double_prime) - STIFFNESS FIX: SMOOTHED KINETICS
T_deg_ref = 573;    % PMMA degradation reference temperature (K)
ramp_width = 15;    % Temperature range over which the rate smoothly ramps up (K)

% Smooth Sigmoid-like activation function (Eliminates sharp 'if Ts >= 573' discontinuity)
smooth_factor = 0.5 * (1 + tanh((Ts - T_deg_ref) / ramp_width));

% Arrhenius Rate (r_s): A * exp(-E/(R*Ts))
rate_Arrhenius = A * exp(-E/(R*Ts));

% Effective Pyrolysis Rate
r_s = smooth_factor * rate_Arrhenius;

% Mass flux (kg/m^2.s) - assume 1st order in solid mass, which is approx constant (rho_s * dx)
m_double_prime = r_s * rho_s * dx; 

% 2.2 Surface Heat Fluxes
q_cond_out = k_s * (T(1) - T(2)) / dx;            % Conduction from surface into interior
q_cond_in_rear = q_ext;                           % External Radiative Flux
q_conv_loss = h_c * (Ts - T_amb);                 % Convective Loss to gas (Simplified)
q_pyr_endothermic = m_double_prime * Lg;          % Endothermic Pyrolysis Heat Loss

% Total net heat input at the surface
q_net_in_surface = q_cond_in_rear - q_conv_loss - q_pyr_endothermic;

% Derivative at node 1 (CV mass * cp)
dTdt(1) = (q_net_in_surface + q_cond_out) / (rho_s * cp_s * (dx/2));

% --- 3. GAS PHASE (Species Transport X_He, X_F) ---

% 3.1 Calculate Surface Velocities and Mole Fractions (X_i,surf)
m_He_flux = V_He_inj * rho_gas; % Injected Helium mass flux
m_F_flux = m_double_prime;      % Pyrolytic Fuel mass flux
m_total_flux = m_He_flux + m_F_flux;

% Calculate Convection Velocity (V_conv) and Surface Mole Fractions (X_i_surf)
if m_total_flux > 1e-12 % Only when there is significant flow
    V_conv = m_total_flux / rho_gas;
    
    % Mass Fractions (Y_i) at the surface
    Y_He = m_He_flux / m_total_flux;
    Y_F = m_F_flux / m_total_flux;
    Y_Air = 1 - Y_He - Y_F;

    % Molar Mass of the mixture (1/M_mix)
    M_mix_inv = Y_He/MW_He + Y_F/MW_F + Y_Air/MW_Air;
    
    % Mole Fractions (X_i) at the surface (Used for the FDM Boundary Condition)
    X_He_surf = (Y_He / MW_He) / M_mix_inv;
    X_F_surf = (Y_F / MW_F) / M_mix_inv;
else
    % Pre-pyrolysis or very low pyrolysis stage
    V_conv = V_He_inj;
    X_He_surf = 1.0;
    X_F_surf = 0.0;
end


% 3.2 Gas Interior Nodes (j=2 to N_gas-1) - Standard Convection-Diffusion FDM
for j = 2:N_gas-1
    % Convection Term (Central Difference)
    Conv_He = rho_gas * V_conv * (X_He(j+1) - X_He(j-1)) / (2 * dy_gas);
    Conv_F  = rho_gas * V_conv * (X_F(j+1) - X_F(j-1)) / (2 * dy_gas);

    % Diffusion Term (Central Difference for second derivative)
    Diff_He = (rho_gas * D_He) * (X_He(j+1) - 2*X_He(j) + X_He(j-1)) / (dy_gas^2);
    Diff_F  = (rho_gas * D_F) * (X_F(j+1) - 2*X_F(j) + X_F(j-1)) / (dy_gas^2);

    % ODE System: dX/dt = (Diffusion - Convection) / rho_gas
    dYdt_gas(j) = (Diff_He - Conv_He) / rho_gas;       % dX_He/dt
    dYdt_gas(j + N_gas) = (Diff_F - Conv_F) / rho_gas; % dX_F/dt
end

% 3.3 Gas Front Boundary (j=1) - STIFFNESS FIX: FLUX BOUNDARY CONDITION FDM
% Flux Balance BC: Flux_i(y=0) = m_i_flux

% We approximate the flux derivative at the first interior control volume (CV)
% using the surface concentration (X_i_surf) and the first interior node (X_i,2).
% This form is derived from the discretization of the conservation equation 
% applied to the first CV:
% (CV Volume) * dX/dt(1) = (Flux_in_surface - Flux_out_to_node_2) / rho_gas

% Fuel (X_F,1)
% Flux_F_in_surface = m_F_flux
% Flux_F_out_to_node_2 (Approximated using FDM 2nd order near the boundary):
dYdt_gas(N_gas + 1) = (2 * D_F / (dy_gas^2)) * (X_F(2) - X_F(1)) + ...
                      (2 * V_conv / dy_gas) * (X_F_surf - X_F(1)) + ...
                      (2 * D_F / dy_gas) * (X_F_surf - X_F(1)) / dy_gas; % Simplified FDM

% Helium (X_He,1)
% Flux_He_in_surface = m_He_flux
dYdt_gas(1) = (2 * D_He / (dy_gas^2)) * (X_He(2) - X_He(1)) + ...
              (2 * V_conv / dy_gas) * (X_He_surf - X_He(1)) + ...
              (2 * D_He / dy_gas) * (X_He_surf - X_He(1)) / dy_gas;


% 3.4 Gas Rear Boundary (j=N_gas) - Ambient Condition (X_i = 0)
% Fixed concentration boundary condition: dX/dt = 0
dYdt_gas(N_gas) = 0;       % X_He,N_gas is fixed at 0 (Ambient Air)
dYdt_gas(2*N_gas) = 0;     % X_F,N_gas is fixed at 0 (Ambient Air)

% --- 4. ASSEMBLE FINAL DERIVATIVE VECTOR ---
dYdt = [dTdt; dYdt_gas];

% Optional safety check to prevent negative mole fractions (less critical with ode15s)
for j = 1:N_gas
    if X_He(j) < 0 && dYdt_gas(j) < 0
        dYdt_gas(j) = 0;
    end
    if X_F(j) < 0 && dYdt_gas(j + N_gas) < 0
        dYdt_gas(j + N_gas) = 0;
    end
end

end