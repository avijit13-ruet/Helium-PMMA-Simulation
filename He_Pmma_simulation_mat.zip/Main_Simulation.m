% Main_Simulation.m: Simplified 1D PMMA Pyrolysis Model (MOL)

% 1. DEFINE PHYSICAL CONSTANTS (Simplified)
global N dx rho_s cp_s k_s E R A Lg q_ext T_amb
global MW_He MW_Air MW_F

% Molecular Weights (kg/mol)
MW_He = 0.0040; % Helium
MW_Air = 0.02896; % Air (average)
MW_F = 0.1001; % PMMA/MMA Fuel (C5H8O2)
% PMMA Properties
rho_s = 1190;
cp_s = 1466; % [1]
k_s = 0.18; % [1]
Lg = 1.8e6; % Heat of Gasification (J/kg)
T_amb = 298.15; % Ambient Temperature (K)

% Pyrolysis Kinetics [2]
R = 8.314;
E = 150000; % Activation Energy (J/mol) (Approximate 36.07 kcal/mol)
A = 2.57e17; % Pre-exponential factor (1/s)

% External Input
q_ext = 10000; % Applied Heat Flux (W/m2)

% 2. GRID AND INITIAL CONDITIONS
L = 0.01;
N = 40;
dx = L / (N - 1);

% Initial T profile and time span
T_initial = T_amb * ones(N, 1);
tspan = [0 150]; % Solve up to 150 seconds

% 3. SOLVER EXECUTION
options = odeset('RelTol', 1e-4, 'AbsTol', 1e-6, 'MaxStep', 0.01); % Add MaxStep limit


% Correct assignment of ode15s output
[t_out, T_out] = ode15s(@Pyrolysis_MOL, tspan, T_initial, options);

% 4. RESULTS PLOTTING
% The surface temperature is the first column of the solution matrix (T_out)
Ts_history = T_out(:, 1);
figure; plot(t_out, Ts_history, 'b-', 'LineWidth', 2);
title('PMMA Surface Temperature Rise');
xlabel('Time (s)');
ylabel('Surface Temperature (K)');
grid on;

% --- New Global Parameters (Add to Main_Simulation.m) ---
global N_gas dy_gas rho_gas D_He D_F R_univ cp_air cp_He h_c V_He_inj

% Gas Properties (Approximate/Baseline)
R_univ = 8.314; % Universal Gas Constant (J/mol.K)
rho_gas = 1.2;  % Average Gas Density (kg/m3) (Approx. Air)
cp_air = 1000;  % Air Specific Heat (J/kg.K)
cp_He = 5193;   % Helium Specific Heat (J/kg.K) [cite: 102]

% Mass Diffusivities (m2/s) - HIGHLY dependent on T, P, Xi, but simplified for initial code
D_He = 7.0e-5;  % Helium-Air Diffusivity (High)
D_F = 6.0e-6;   % MMA Fuel-Air Diffusivity (Low)

% Boundary Layer Grid
L_gas = 0.01;   % Gas domain length (10 mm)
N_gas = 40;     % Gas nodes
dy_gas = L_gas / (N_gas - 1);

% Input Variables
h_c = 10;       % Initial guess for Convective Heat Transfer Coeff (W/m2.K)
V_He_inj = 0.05;% Helium Injection Velocity (m/s) (This is Q1's optimization variable)